﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;

using log4net;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Configuration;

using System.Web;
using System.Net;
using System.Threading;
using System.Diagnostics;
using System.Collections;
using System.Data.Objects;
using System.Globalization;
using Microsoft.Office.Interop.Excel;

namespace LEXKPIReporting
{
    public partial class KPIReport : Form
    {
        string sheetName;
        DataSet ds;
        DataSet dsHeader;
        List<string> comboBoxData = new List<string>();
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        List<ReportEntity> records = new List<ReportEntity>();
        List<ReportEntity> Nonrecords = new List<ReportEntity>();
        List<string> Templatecolumns = new List<string>(ConfigurationManager.AppSettings["Columns"].Split(new char[] { ';' }));
       
        string basePath;

       
        
        string strFinalNonTrimFileName;
        string strFinalFileName;
        int recordsCount = 0;
        int NonTrimrecordsCount = 0;
        WebClient client;
        long TotalRecordCount = 0;
        long TotalKPIEntityCount = 0;

        public KPIReport()
        {
            InitializeComponent();
            log4net.Config.XmlConfigurator.Configure();
            client = new WebClient();
           
            basePath = AppDomain.CurrentDomain.BaseDirectory + @"Reports";
        }

        private void btnLoadWS_Click(object sender, EventArgs e)
        {
            /*
         This method to bind the DataSet [ Validated Excel Data ]  into the DataGridView for check.
         It will load into Datasets if everything validated properly and exit the program if any validation fails.
        */

            int index = cboWorksheets.SelectedIndex;

            try
            {
                if (cboWorksheets.SelectedIndex == -1)
                {
                    MessageBox.Show("Please click Select Workbook",
                                 "Important Note",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Information,
                                 MessageBoxDefaultButton.Button1);

                    return;
                }
                else
                {
                    if (ds.Tables.Count > 0 && dsHeader.Tables.Count > 0)
                    {
                        DataGridView1.DataSource = ds.Tables[index];
                        //Resize the height of the column headers. 
                        DataGridView1.AutoResizeColumnHeadersHeight();
                        // Resize all the row heights to fit the contents of all non-header cells.
                        DataGridView1.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders);
                        DataGridView1.AutoResizeColumn(0);
                        int rowCount = ds.Tables[index].Rows.Count - 1;
                        lblRowsLoaded.Text = "TableName: " + ds.Tables[index].TableName + " has " + rowCount + " rows";
                        LogMessageToFile(lblRowsLoaded.Text);
                        log.Info("Excel Rows:" + lblRowsLoaded.Text);
                        labProgress.Text = "Data loaded in the Grid for reference";
                    }
                    else
                    {
                        DataGridView1.DataSource = null;
                        ds = null;
                        dsHeader = null;
                        lblRowsLoaded.Text = "";
                        MessageBox.Show("TableName: " + ds.Tables[index].TableName + " has some problem \n while loading into GrideView.",
                        "Warning",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning,
                        MessageBoxDefaultButton.Button1);

                        LogMessageToFile("TableName: " + ds.Tables[index].TableName + " has some problem while loading into GrideView.Please reupload excel and try again");
                        log.Warn("TableName: " + ds.Tables[index].TableName + " has some problem while loading into GrideView.Please reupload excel and try again");
                        return;
                    }

                }
            }
            catch (Exception ex)
            {
                // Log exception for developers
                log.Error("Error loading excel into the Grid:" + ex.Message);

                // Display message to users
                MessageBox.Show("An error has occurred, please contact support!",
                            "Critical Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error,
                            MessageBoxDefaultButton.Button1);
            }
        }

        public void LogMessageToFile(string msg)
        {
            /*
                This function to write the Debug -Info into the log file for Tech team verfications
           */

            System.IO.StreamWriter sw = System.IO.File.AppendText(
                GetTempPath() + "KPIReport_Info.txt");
            try
            {
                string logLine = System.String.Format(
                    "{0:G}: {1}.", System.DateTime.Now, msg);
                sw.WriteLine(logLine);
            }
            finally
            {
                sw.Close();
            }
        }

        public string GetTempPath()
        {
            /*
                This function to get the Temp path defined in the App.Config file 
           */


            if (ConfigurationManager.AppSettings["LogFilePath"] != null)
            {
                Globals.AppLogValue = ConfigurationManager.AppSettings["LogFilePath"];

                Globals.LogFilePath = System.Environment.ExpandEnvironmentVariables(Globals.AppLogValue);

                if (!Globals.LogFilePath.EndsWith("\\")) Globals.LogFilePath += "\\";
                // MessageBox.Show("If condition");
            }
            else
            {
                log.Error("Log File Path is Empty in the App.Config, Please check the config file!");
                MessageBox.Show("An error has occurred, please contact support!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                


            }
            return Globals.LogFilePath;
        }

        private DataSet SetDataTablesFromExcel(string tempfilePath)
        {

            /*
           This method to validate the Excel Rows, Format, Columns and whether anything Empty or not.
           It will load into Datasets if everything validated properly and exit the program if any validation fails.
          */

            var filePath = tempfilePath;
            ds = new DataSet();
            dsHeader = new DataSet();
            string connString = string.Empty;
            string RowValue = "";
            try
            {

                //Load the Predefined Excel Columns from App.Config and store into List for further comparision with Excel upload
                var Templatecolumns = new List<string>(ConfigurationManager.AppSettings["Columns"].Split(new char[] { ';' }));
                List<string> ExcelColumns = new List<string>();
                int comBoCount = cboWorksheets.Items.Count;


                FileInfo file = new FileInfo(filePath);
                if (!file.Exists) { throw new Exception("Error, file doesn't exists!"); }
                string extension = file.Extension;

                switch (extension)
                {
                    //2003 Format
                    case ".xls":
                        connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=No;IMEX=1;'";
                        //connString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR=No'", filePath);
                        break;
                    //2007 & above Format
                    case ".xlsx":
                        connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 12.0;HDR=No;IMEX=1;'";
                        break;
                    default:
                        connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=No;IMEX=1;'";
                        break;
                }

                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter())
                        {
                            cmd.Connection = con;
                            con.Open();
                            System.Data.DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                            for (int i = 0; i < dtExcelSchema.Rows.Count; i++)
                            {
                                sheetName = dtExcelSchema.Rows[i]["TABLE_NAME"].ToString();
                                System.Data.DataTable dt = new System.Data.DataTable();
                                cmd.Connection = con;
                                //Read all the rows from Excel sheet
                                cmd.CommandText = "SELECT * FROM [" + sheetName + "]";
                                oda.SelectCommand = cmd;
                                oda.Fill(dt);
                                dt.TableName = sheetName;
                                //Validate the Excel Rows empty or not
                                RowValue = dt.Rows[0][0].ToString();
                                bool validate = string.IsNullOrEmpty(RowValue);
                                if (validate)
                                {
                                    // MyMessage.ShowMessage("The excel sheet" + sheetName + ":contains no rows and cannot process", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    MessageBox.Show("The excel sheet" + sheetName + ":contains no rows and cannot process",
                                   "Critical Warning",
                                   MessageBoxButtons.OK,
                                   MessageBoxIcon.Warning,
                                   MessageBoxDefaultButton.Button1);
                                    break;
                                }
                                //Read the Header Rows only
                                cmd.CommandText = "SELECT top 1 * From [" + sheetName + "]";
                                System.Data.DataTable HeaderColumns = new System.Data.DataTable();
                                oda.SelectCommand = cmd;
                                oda.Fill(HeaderColumns);

                                //Validate the Excel Columns as per the Template Columns as anything missing or empty
                                foreach (DataColumn column in HeaderColumns.Columns)
                                {
                                    string columnName = HeaderColumns.Rows[0][column.ColumnName].ToString().Trim();
                                    ExcelColumns.Add(columnName);
                                }

                                var result = ExcelColumns.Where(c => Templatecolumns.Contains(c));
                                var Missingresult = Templatecolumns.Where(p => !ExcelColumns.Any(p2 => p2.ToString() == p.ToString()));
                                //if the result greater than zero, then it will display the missing excel columns and exit the program.
                                if (Missingresult.Count() > 0)
                                {
                                    string MissingColumns = String.Join(",", Missingresult);
                                    ds = null;
                                    dsHeader = null;
                                    lblRowsLoaded.Text = "";

                                    MessageBox.Show("Expected Column names missing in the Excel: \n " + Globals.tempfilePath + " Name \n: " + cboWorksheets.SelectedItem + " : with Column Name: \n" + MissingColumns + ".",
                                   "Critical Warning",
                                   MessageBoxButtons.OK,
                                   MessageBoxIcon.Warning,
                                   MessageBoxDefaultButton.Button1);

                                    // MyMessage.ShowMessage("Expected Column names missing in the Excel: \n " + Globals.tempfilePath + " Name \n: " + cboWorksheets.SelectedItem + " : with Column Name: \n" + MissingColumns + ".", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LogMessageToFile("Expected Column names missing in the Excel, " + Globals.tempfilePath + " Name:  \n" + cboWorksheets.SelectedItem + " : with Column Name: \n" + MissingColumns + "");
                                    log.Warn("Expected Column names missing in the Excel, " + Globals.tempfilePath + " Name:  \n" + cboWorksheets.SelectedItem + " : with Column Name: \n" + MissingColumns + "");
                                    break;
                                }
                                //Adding Excel Data and Header as each datatable and add into the Dataset;Adding the sheet names into the Combo box
                                dsHeader.Tables.Add(HeaderColumns);
                                ds.Tables.Add(dt);
                                comboBoxData.Add(sheetName.Replace("$", ""));
                                ExcelColumns.Clear();

                            }
                            //Clear the DataTable to load from OLEDB
                            dtExcelSchema.Dispose();
                            cboWorksheets.DataSource = comboBoxData;
                        }
                        if (cmd != null)
                            cmd.Dispose();
                    }
                    if (con != null)
                        con.Close();

                }

            }
            catch (Exception ex)
            {

                // Log exception for developers
                log.Error("Error during SetDataTablesFromExcel Method execution:" + ex.Message);

                // Display message to users

                MessageBox.Show("An error has occurred, please contact support!",
                            "Critical Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error,
                            MessageBoxDefaultButton.Button1);
                ds = null;
            }
            finally
            {
                connString = "";
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return ds;
        }

        private void btnSelectWorkbook_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                try
                {

                    openFileDialog.Filter = "Excel Worksheets|*.xls;*.xlsx;*.xlsm; *.xlsb";
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.Multiselect = false;        //not allow multiline selection at the file selection level
                    openFileDialog.Title = "Choose Disposal Register Excel";   //define the name of openfileDialog
                    openFileDialog.InitialDirectory = @"Desktop"; //define the initial directory
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK) //executing when file open
                    {
                        //Get the path of specified file
                        Globals.tempfilePath = openFileDialog.FileName;
                        //Clear the Datasource for Combo box, GridView before validate and bind the excel Data into Dataset
                        cboWorksheets.DataSource = null;
                        cboWorksheets.Items.Clear();
                        comboBoxData.Clear();
                        labProgress.Text = "Ready to load data";
                        DataGridView1.DataSource = null;
                        DataGridView1.Rows.Clear();
                        DataGridView1.Refresh();
                        ds = SetDataTablesFromExcel(Globals.tempfilePath);
                        if (ds != null)
                        {
                            if (ds.Tables.Count > 0)
                                MessageBox.Show("All the Data processed successfully.  Please click Load \n if you would like to check the content of the spreadsheet.", "Process Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        //cboWorksheets.SelectedIndex = 0;
                    }
                    else if (openFileDialog.ShowDialog() == DialogResult.Cancel)
                    {
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Log exception for developers
                    log.Error("Error during Select Excel process :" + ex.Message);

                    // Display message to users
                    MessageBox.Show("An error has occurred, please contact support!",
                             "Critical Error",
                             MessageBoxButtons.OK,
                             MessageBoxIcon.Error,
                             MessageBoxDefaultButton.Button1);

                }
            }

        }

        private void btnGenerateKPI_Click(object sender, EventArgs e)
        {
            List<KPIDaysCalcEntity> KPIEntity = new List<KPIDaysCalcEntity>();
            DateTime EndDate = new DateTime();
            DateTime EndDateN = new DateTime();
            DateTime DueDate = new DateTime();
            DateTime CloseDate = new DateTime();
            //DateTime OpenDate = new DateTime();
            string tempEndDate = string.Empty;
            string tempEndDateN = string.Empty;
            string tempDueDate = string.Empty;
            string tempCloseDate = string.Empty;
            string tempOpenDate = string.Empty;
            double dateDiff=0;
            double breachSLADiff=0;
            string strDateTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string strFileName = string.Empty;
            strFileName = "KPI Report" + "_" + "Statistics" + "_" + strDateTime;

            var watch = Stopwatch.StartNew();

            if (!Directory.Exists(basePath))
            {
                DirectoryInfo di = Directory.CreateDirectory(basePath);

            }
            try
            {
                if (ds == null)
                {

                    MessageBox.Show("Please select the Excel Workbook before run the KPI report!",
                    "Warning",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button1);

                    return;
                }
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var myData1 = ds.Tables[0].AsEnumerable().Skip(1)
                             .Select(r => new
                             {

                                 LEX_ID = r[0].ToString(),
                                 Matter = r[1].ToString(),
                                 Importance = r[2].ToString(),
                                 Status = r[3].ToString(),
                                 Open_date = r[4].ToString(),
                                 Close_date = r[5].ToString(),
                                 Due_date = r[6].ToString(),
                                 Date = r[7].ToString(),
                                 Key_Date_Type = r[8].ToString(),
                                 Notes = r[9].ToString()
                                // Days = DateTime.Parse(r[6].ToString()) - DateTime.Parse((r[4].ToString()))

                                 /*etc*/
                                 
                             });
                    var list1 = myData1.ToList().OrderBy(x => x.LEX_ID).ThenBy(x => x.Key_Date_Type).ToList();
                  
                   // var list2 = list1.GroupBy(user => user.LEX_ID).ToList();

                    //var list2 = list1
                    // .GroupBy(u => u.LEX_ID)
                    //.Select( grp => grp.ToList())
                    // .ToList();

                    TotalRecordCount = list1.Count();

                    if (TotalRecordCount > 0)
                    {
                        for (int i = 0; i < TotalRecordCount; i++)
                        //  foreach (var item in list1)
                        {
                           // list1[i].LEX_ID.ToString() == list1[i + 1].LEX_ID.ToString()
                           if ((i + 1) != TotalRecordCount)
                            {

                                tempEndDateN = list1[i + 1].Date.ToString();
                                if (tempEndDateN != "")
                                    EndDateN = DateTime.ParseExact(tempEndDateN, "d-MMM-yy", CultureInfo.InvariantCulture);
                                // tempDueDate = item.Due_date;
                                //tempDueDate = list1[i].Due_date.ToString();
                                tempEndDate = list1[i].Date.ToString();
                                if (tempEndDate != "")
                                    EndDate = DateTime.ParseExact(tempEndDate, "d-MMM-yy", CultureInfo.InvariantCulture);
                                if ((EndDate != DateTime.MinValue) && (EndDateN != DateTime.MinValue))
                                {
                                    dateDiff = (EndDateN - EndDate).TotalDays;
                                    // It is 972 days from the start date to the end date, but not including the end date 
                                    //[start date is 01-Feb-2018. and end date is 30-Sep-2020
                                }
                                else
                                {
                                    dateDiff = 0;
                                }

                               
                            }

                            //tempCloseDate = item.Close_date;
                            tempCloseDate = list1[i].Close_date.ToString();
                            if (tempCloseDate != "")
                                CloseDate = DateTime.ParseExact(tempCloseDate, "d-MMM-yy", CultureInfo.InvariantCulture);

                            tempDueDate = list1[i].Due_date.ToString();
                            if (tempDueDate != "")
                                DueDate = DateTime.ParseExact(tempDueDate, "d-MMM-yy", CultureInfo.InvariantCulture);
                            if ((CloseDate != DateTime.MinValue) && (DueDate != DateTime.MinValue))
                            {
                                breachSLADiff = (CloseDate - DueDate).TotalDays;

                            }
                            else
                            {
                                breachSLADiff = 0;
                            }


                            KPIEntity.Add(new KPIDaysCalcEntity()
                            {
                                LEX_ID = list1[i].LEX_ID.ToString(),
                                Matter = list1[i].Matter.ToString().Trim(),
                                Importance = list1[i].Importance.ToString().Trim(),
                                Status = list1[i].Status.ToString(),
                                Open_date = list1[i].Open_date.ToString(),
                                Close_date = list1[i].Close_date.ToString(),
                                Due_date = list1[i].Due_date.ToString(),
                                Date = list1[i].Date.ToString(),
                                Key_Date_Type = list1[i].Key_Date_Type.ToString(),
                                Notes = list1[i].Notes.ToString().Trim(),
                                No_Of_Days = dateDiff.ToString(),
                                BreachSLADays = breachSLADiff.ToString()
                            }
                            );
                            /*
                            KPIEntity = new List<KPIDaysCalcEntity>()
                                        {
                                            new KPIDaysCalcEntity
                                            {
                                                LEX_ID = item.LEX_ID,
                                                Matter = item.Matter,
                                                Importance = item.Importance,
                                                Status = item.Status,
                                                Open_date = item.Open_date,
                                                Due_date = item.Due_date,
                                                Close_date = item.Close_date,
                                                Date = item.Date,
                                                Key_Date_Type = item.Key_Date_Type,
                                                Notes = item.Notes,
                                                No_Of_Days = dateDiff.ToString(),
                                                BreachSLADays = breachSLADiff.ToString()
                                            }

                                        };*/

                            TotalKPIEntityCount++;
                        }//end of for loop
                    }
                    TotalKPIEntityCount = KPIEntity.Count;
                    
                    ExportData.ExportCsv(KPIEntity, strFileName);
                }
                else
                {

                    MessageBox.Show("Please select the Excel before start process!",
                    "Warning",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button1);
                }

                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                log.Info("Total Records processed:" + TotalRecordCount);
                log.Info("Total time to complete the process:" + elapsedMs);
                MessageBox.Show("Success");
            }
            catch (Exception ex)
            {
                // Log exception for developers
                log.Error("Error loading KPI process:" + ex.Message);

                // Display message to users
                MessageBox.Show("An error has occurred, please contact support!",
                           "Critical Error",
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Error,
                           MessageBoxDefaultButton.Button1);

            }
        }
    }
}
