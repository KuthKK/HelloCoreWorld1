﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEXKPIReporting
{
    class KPIDaysCalcEntity
    {
        public string LEX_ID { get; set; }

        public string Matter { get; set; }

        public string Importance { get; set; }

        public string Status { get; set; }

        public string Open_date { get; set; }

        public string Close_date { get; set; }

        public string Due_date { get; set; }

        public string Date { get; set; }

        public string Key_Date_Type { get; set; }

        public string Notes { get; set; }

        public string No_Of_Days { get; set; }

        public string BreachSLADays { get; set; }

    }
}
