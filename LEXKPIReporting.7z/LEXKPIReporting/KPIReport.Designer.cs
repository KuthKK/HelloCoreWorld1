﻿namespace LEXKPIReporting
{
    partial class KPIReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.labProgress = new System.Windows.Forms.Label();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblRowsLoaded = new System.Windows.Forms.Label();
            this.btnLoadWS = new System.Windows.Forms.Button();
            this.cboWorksheets = new System.Windows.Forms.ComboBox();
            this.btnSelectWorkbook = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDownload = new System.Windows.Forms.Button();
            this.lblResolved = new System.Windows.Forms.Label();
            this.btnGenerateKPI = new System.Windows.Forms.Button();
            this.rbDestroy = new System.Windows.Forms.RadioButton();
            this.rbArchive = new System.Windows.Forms.RadioButton();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(805, 455);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.progressBar2);
            this.tabPage1.Controls.Add(this.labProgress);
            this.tabPage1.Controls.Add(this.DataGridView1);
            this.tabPage1.Controls.Add(this.lblRowsLoaded);
            this.tabPage1.Controls.Add(this.btnLoadWS);
            this.tabPage1.Controls.Add(this.cboWorksheets);
            this.tabPage1.Controls.Add(this.btnSelectWorkbook);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(797, 429);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Spreadsheet";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(389, 396);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(258, 23);
            this.progressBar2.TabIndex = 10;
            // 
            // labProgress
            // 
            this.labProgress.AutoSize = true;
            this.labProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labProgress.Location = new System.Drawing.Point(8, 406);
            this.labProgress.MaximumSize = new System.Drawing.Size(100, 0);
            this.labProgress.MinimumSize = new System.Drawing.Size(300, 0);
            this.labProgress.Name = "labProgress";
            this.labProgress.Size = new System.Drawing.Size(300, 13);
            this.labProgress.TabIndex = 9;
            this.labProgress.Text = "Ready";
            // 
            // DataGridView1
            // 
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView1.Location = new System.Drawing.Point(8, 86);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.Size = new System.Drawing.Size(776, 302);
            this.DataGridView1.TabIndex = 8;
            // 
            // lblRowsLoaded
            // 
            this.lblRowsLoaded.AutoSize = true;
            this.lblRowsLoaded.Location = new System.Drawing.Point(574, 36);
            this.lblRowsLoaded.Name = "lblRowsLoaded";
            this.lblRowsLoaded.Size = new System.Drawing.Size(73, 13);
            this.lblRowsLoaded.TabIndex = 7;
            this.lblRowsLoaded.Text = "0 rows loaded";
            // 
            // btnLoadWS
            // 
            this.btnLoadWS.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnLoadWS.Location = new System.Drawing.Point(405, 21);
            this.btnLoadWS.Name = "btnLoadWS";
            this.btnLoadWS.Size = new System.Drawing.Size(141, 33);
            this.btnLoadWS.TabIndex = 6;
            this.btnLoadWS.Text = "Load";
            this.btnLoadWS.UseVisualStyleBackColor = false;
            this.btnLoadWS.Click += new System.EventHandler(this.btnLoadWS_Click);
            // 
            // cboWorksheets
            // 
            this.cboWorksheets.FormattingEnabled = true;
            this.cboWorksheets.Location = new System.Drawing.Point(221, 28);
            this.cboWorksheets.Name = "cboWorksheets";
            this.cboWorksheets.Size = new System.Drawing.Size(121, 21);
            this.cboWorksheets.TabIndex = 2;
            // 
            // btnSelectWorkbook
            // 
            this.btnSelectWorkbook.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnSelectWorkbook.Location = new System.Drawing.Point(26, 21);
            this.btnSelectWorkbook.Name = "btnSelectWorkbook";
            this.btnSelectWorkbook.Size = new System.Drawing.Size(141, 33);
            this.btnSelectWorkbook.TabIndex = 1;
            this.btnSelectWorkbook.Text = "Select Workbook";
            this.btnSelectWorkbook.UseVisualStyleBackColor = false;
            this.btnSelectWorkbook.Click += new System.EventHandler(this.btnSelectWorkbook_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(797, 429);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "KPI Calculation";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDownload);
            this.groupBox1.Controls.Add(this.lblResolved);
            this.groupBox1.Controls.Add(this.btnGenerateKPI);
            this.groupBox1.Controls.Add(this.rbDestroy);
            this.groupBox1.Controls.Add(this.rbArchive);
            this.groupBox1.Location = new System.Drawing.Point(6, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(580, 310);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "KPI Report";
            // 
            // btnDownload
            // 
            this.btnDownload.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnDownload.Location = new System.Drawing.Point(405, 144);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(156, 37);
            this.btnDownload.TabIndex = 11;
            this.btnDownload.Text = "Download";
            this.btnDownload.UseVisualStyleBackColor = false;
            this.btnDownload.Visible = false;
            // 
            // lblResolved
            // 
            this.lblResolved.AutoSize = true;
            this.lblResolved.Location = new System.Drawing.Point(313, 152);
            this.lblResolved.Name = "lblResolved";
            this.lblResolved.Size = new System.Drawing.Size(0, 13);
            this.lblResolved.TabIndex = 10;
            // 
            // btnGenerateKPI
            // 
            this.btnGenerateKPI.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnGenerateKPI.Location = new System.Drawing.Point(405, 46);
            this.btnGenerateKPI.Name = "btnGenerateKPI";
            this.btnGenerateKPI.Size = new System.Drawing.Size(156, 37);
            this.btnGenerateKPI.TabIndex = 0;
            this.btnGenerateKPI.Text = "Go";
            this.btnGenerateKPI.UseVisualStyleBackColor = false;
            this.btnGenerateKPI.Click += new System.EventHandler(this.btnGenerateKPI_Click);
            // 
            // rbDestroy
            // 
            this.rbDestroy.AutoSize = true;
            this.rbDestroy.Location = new System.Drawing.Point(28, 72);
            this.rbDestroy.Name = "rbDestroy";
            this.rbDestroy.Size = new System.Drawing.Size(61, 17);
            this.rbDestroy.TabIndex = 2;
            this.rbDestroy.TabStop = true;
            this.rbDestroy.Text = "Destroy";
            this.rbDestroy.UseVisualStyleBackColor = true;
            this.rbDestroy.Visible = false;
            // 
            // rbArchive
            // 
            this.rbArchive.AutoSize = true;
            this.rbArchive.Enabled = false;
            this.rbArchive.Location = new System.Drawing.Point(126, 72);
            this.rbArchive.Name = "rbArchive";
            this.rbArchive.Size = new System.Drawing.Size(61, 17);
            this.rbArchive.TabIndex = 3;
            this.rbArchive.TabStop = true;
            this.rbArchive.Text = "Archive";
            this.rbArchive.UseVisualStyleBackColor = true;
            this.rbArchive.Visible = false;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.WorkerSupportsCancellation = true;
            // 
            // KPIReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "KPIReport";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblRowsLoaded;
        private System.Windows.Forms.Button btnLoadWS;
        private System.Windows.Forms.ComboBox cboWorksheets;
        private System.Windows.Forms.Button btnSelectWorkbook;
        private System.Windows.Forms.DataGridView DataGridView1;
        private System.Windows.Forms.Label labProgress;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Label lblResolved;
        private System.Windows.Forms.Button btnGenerateKPI;
        private System.Windows.Forms.RadioButton rbDestroy;
        private System.Windows.Forms.RadioButton rbArchive;
    }
}

