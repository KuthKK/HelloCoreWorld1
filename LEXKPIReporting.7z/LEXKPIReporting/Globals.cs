﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using Excel = Microsoft.Office.Interop.Excel;


namespace LEXKPIReporting
{
    public static class Globals
    {
        /*
             The Global Variable Declaration Section
             Contains all the global definitions that we are goign to use thrughout the program

            */


        public static bool blWorking;
        public static bool blCancel;
     
        public static string App_Name;
        public static System.Threading.Thread Thread1;
        public static System.Threading.Thread Thread2;
        public static string DBID = string.Empty;
        public static string AppLogValue = string.Empty;
        public static string LogFilePath = string.Empty;
        public static string tempfilePath = string.Empty;
        //public static Form PF;
        public static bool blSaveChanges;
        public static string Separator = ",";
        public static string Filepath = "";
        public static bool QuoteActive = false;
        public static bool btnLoadClicked = false;
        public static bool cmbIndexChanged = false;
        public static bool LimitSearchSize = false;
        public static long SearchSize = 10000;
        public static string[,] List; // holds data from the DataGridView
        public static Excel.Application excelApp;
        public static Excel.Workbook excelWB;
        public static Excel.Worksheet excelWS;
        public static bool blSSloaded; // flags if the spreadsheet data is loaded
        //public static FileLog4 g_ApplicationLog;
        public static string g_AuditLogPath;
        public static string g_ApplicationErrorLogPath;
        public static string g_WorkingFolderPath;
        public static string g_ReportsPath;
        public static bool g_FormInitialized = false;
        public static int countLinesinSpreadsheet;
        public static int countBarcodesProcessed;
        public static int countRecordsToBeDisposed;
        public static int countRecordsDisposed;
        public static StreamWriter sw;
    }
}
